# Protótipo de Mapa Interativo

Protótipo front-end de um mapa interativo criado com **HTML**, **CSS**, **JavaScript**, **SVG** e **JSON**.

O objetivo deste repositório é demonstrar uma base técnica de interação visual: carregar um SVG no navegador, localizar elementos pelo ID, aplicar cores dinamicamente conforme um arquivo JSON e permitir testes manuais pela interface.

## Tecnologias utilizadas

- HTML5
- CSS3
- JavaScript
- SVG
- JSON

## Funcionalidades demonstradas

- Renderização de um mapa em SVG no navegador
- Identificação de áreas pelo atributo `id`
- Alteração dinâmica de cores conforme status
- Leitura de dados fictícios a partir de `lotes.json`
- Painel lateral com legenda, teste manual e edição temporária do JSON
- Exibição de informações básicas ao clicar em um item do mapa

## Como executar localmente

1. Baixe ou clone este repositório.
2. Abra o terminal dentro da pasta do projeto.
3. Execute:

```bash
python -m http.server 8000
```

4. Acesse no navegador:

```text
http://localhost:8000
```

> Observação: abrir o `index.html` diretamente pode impedir o carregamento do JSON em alguns navegadores. Por isso, o ideal é executar com um servidor local simples.

## Estrutura do projeto

```text
.
├── index.html
├── style.css
├── script.js
├── lotes.json
└── mapa.svg
```

## Sobre os dados

Todos os dados deste projeto são fictícios e usados apenas para fins de demonstração técnica.
