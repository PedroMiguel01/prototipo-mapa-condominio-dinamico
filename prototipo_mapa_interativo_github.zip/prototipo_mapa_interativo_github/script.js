// =======================================================
// Protótipo de mapa interativo
// SVG + JavaScript + JSON local com dados fictícios
// =======================================================

const CORES = {
  disponivel: { fill: '#4CAF7A', stroke: '#2F7A52', nome: 'Disponível' },
  reservado:  { fill: '#D4A437', stroke: '#9A741F', nome: 'Reservado' },
  em_uso:     { fill: '#3A6EA5', stroke: '#274B73', nome: 'Em uso' },
  concluido:  { fill: '#1F4E79', stroke: '#163653', nome: 'Concluído' }
};

let ITENS_CACHE = [];

async function buscarDados() {
  const resposta = await fetch('lotes.json?_=' + Date.now());
  if (!resposta.ok) throw new Error('Erro ao carregar dados: ' + resposta.status);
  return await resposta.json();
}

function getSvgDoc(){
  const obj = document.getElementById('svgMapa');
  return obj?.contentDocument || null;
}

function obterShape(svgDoc, idItem){
  const el = svgDoc.getElementById(idItem);
  if (!el) return null;

  const tag = el.tagName.toLowerCase();
  if (['rect','path','polygon','circle','ellipse'].includes(tag)) return el;

  return el.querySelector('rect,path,polygon,circle,ellipse');
}

function pintarItem(svgDoc, item){
  const el = obterShape(svgDoc, item.id_lote);
  if(!el) return false;

  const cor = CORES[item.status] || CORES.disponivel;

  el.style.setProperty('fill', cor.fill, 'important');
  el.style.setProperty('stroke', cor.stroke, 'important');
  el.style.setProperty('stroke-width', '1.2', 'important');
  el.style.setProperty('fill-opacity', '1', 'important');
  el.style.cursor = 'pointer';

  el.dataset.status = item.status;
  el.dataset.area = item.area_m2 || '';
  el.dataset.grupo = item.grupo || '';
  el.dataset.numero = item.numero || '';

  el.onmouseenter = () => {
    el.style.setProperty('filter', 'brightness(0.92)', 'important');
  };
  el.onmouseleave = () => {
    el.style.removeProperty('filter');
  };
  el.onclick = () => mostrarInfo(item, cor.nome);

  return true;
}

function mostrarInfo(item, statusNome){
  document.getElementById('info').innerHTML = `
    <b>${item.id_lote}</b><br>
    Grupo: ${item.grupo || '-'}<br>
    Número: ${item.numero || '-'}<br>
    Status: ${statusNome}<br>
    Área: ${item.area_m2 || '-'} m²
  `;
}

function preencherSelectItens(itens){
  const select = document.getElementById('loteManual');
  select.innerHTML = '';

  itens.forEach(item => {
    const opt = document.createElement('option');
    opt.value = item.id_lote;
    opt.textContent = `${item.id_lote} ${item.grupo ? '(' + item.grupo + ')' : ''}`;
    select.appendChild(opt);
  });
}

async function carregarStatus(){
  const svgDoc = getSvgDoc();
  if(!svgDoc){
    document.getElementById('info').innerHTML = '<span class="erro">SVG ainda não carregou.</span>';
    return;
  }

  try {
    const itens = await buscarDados();
    ITENS_CACHE = itens;

    preencherSelectItens(itens);
    document.getElementById('jsonEditor').value = JSON.stringify(itens.slice(0, 6), null, 2);

    let encontrados = 0;
    let naoEncontrados = [];

    itens.forEach(item => {
      if(pintarItem(svgDoc, item)) {
        encontrados++;
      } else {
        naoEncontrados.push(item.id_lote);
      }
    });

    document.getElementById('info').innerHTML =
      `<span class="ok">${encontrados} item(ns) atualizados no SVG.</span>` +
      (naoEncontrados.length ? `<br><span class="erro">Não encontrados: ${naoEncontrados.join(', ')}</span>` : '');

  } catch (err) {
    document.getElementById('info').innerHTML = '<span class="erro">' + err.message + '</span>';
  }
}

function alterarManual(){
  const svgDoc = getSvgDoc();
  const id = document.getElementById('loteManual').value;
  const status = document.getElementById('statusManual').value;

  const itemBase = ITENS_CACHE.find(l => l.id_lote === id) || { id_lote:id };
  const itemAtualizado = { ...itemBase, status };

  pintarItem(svgDoc, itemAtualizado);
  mostrarInfo(itemAtualizado, CORES[status].nome);

  ITENS_CACHE = ITENS_CACHE.map(l => l.id_lote === id ? itemAtualizado : l);
}

function aplicarJsonDaTela(){
  const svgDoc = getSvgDoc();
  try{
    const itens = JSON.parse(document.getElementById('jsonEditor').value);
    let encontrados = 0;
    itens.forEach(item => { if(pintarItem(svgDoc, item)) encontrados++; });
    document.getElementById('info').innerHTML = `<span class="ok">${encontrados} item(ns) atualizados pelo JSON da tela.</span>`;
  }catch(e){
    document.getElementById('info').innerHTML = '<span class="erro">JSON inválido: ' + e.message + '</span>';
  }
}

document.getElementById('svgMapa').addEventListener('load', carregarStatus);
